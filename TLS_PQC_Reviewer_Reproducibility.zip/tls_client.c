/* Fresh-client diagnostic. Timed SSL_connect excludes process startup and TCP connect.
 * Compile with OpenSSL 3.5+ headers and libraries. No keys or sessions are exported. */
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/x509v3.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
static double ms(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec*1000.0+t.tv_nsec/1e6;}
static void fail(const char *s){fprintf(stderr,"%s\n",s);ERR_print_errors_fp(stderr);exit(2);}
int main(int argc,char **argv){
 if(argc!=5){fprintf(stderr,"port group ca payload\n");return 2;}
 SSL_CTX *ctx=SSL_CTX_new(TLS_client_method());if(!ctx)fail("ctx");
 if(!SSL_CTX_set_min_proto_version(ctx,TLS1_3_VERSION)||!SSL_CTX_set_max_proto_version(ctx,TLS1_3_VERSION))fail("version");
 SSL_CTX_set_verify(ctx,SSL_VERIFY_PEER,NULL);
 if(!SSL_CTX_load_verify_locations(ctx,argv[3],NULL)||!SSL_CTX_set1_groups_list(ctx,argv[2]))fail("trust or group");
 int fd=socket(AF_INET,SOCK_STREAM,0);struct timeval tv={10,0};
 setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof(tv));setsockopt(fd,SOL_SOCKET,SO_SNDTIMEO,&tv,sizeof(tv));
 struct sockaddr_in sa={0};sa.sin_family=AF_INET;sa.sin_port=htons(atoi(argv[1]));inet_pton(AF_INET,"127.0.0.1",&sa.sin_addr);
 if(connect(fd,(struct sockaddr*)&sa,sizeof(sa))!=0)fail("connect");
 SSL *ssl=SSL_new(ctx);SSL_set_fd(ssl,fd);SSL_set_tlsext_host_name(ssl,"localhost");if(!SSL_set1_host(ssl,"localhost"))fail("hostname");
 double t0=ms();int ok=SSL_connect(ssl);double elapsed=ms()-t0;
 if(ok!=1||SSL_get_verify_result(ssl)!=X509_V_OK)fail("handshake or verify");
 const char *group=SSL_group_to_name(ssl,SSL_get_negotiated_group(ssl));if(!group||strcasecmp(group,argv[2]))fail("group mismatch");
 if(SSL_session_reused(ssl))fail("unexpected resumed session");
 const char *req="GET /payload.bin HTTP/1.0\r\nHost: localhost\r\nConnection: close\r\n\r\n";
 if(SSL_write(ssl,req,strlen(req))!=(int)strlen(req))fail("request");
 char response[65536];int total=0,n;
 while(total<(int)sizeof(response)-1&&(n=SSL_read(ssl,response+total,sizeof(response)-1-total))>0)total+=n;
 response[total]=0;char *body=strstr(response,"\r\n\r\n");int skip=4;if(!body){body=strstr(response,"\n\n");skip=2;}
 FILE *f=fopen(argv[4],"rb");if(!f)fail("payload file");char expected[1024];size_t want=fread(expected,1,sizeof(expected),f);fclose(f);
 int http_ok=!strncmp(response,"HTTP/1.0 200 ",13)||!strncmp(response,"HTTP/1.1 200 ",13);
 if(!body||!http_ok||total-(body+skip-response)!=(int)want||memcmp(body+skip,expected,want))fail("incomplete fixed response");
 printf("{\"handshake_ms\":%.9f,\"verified\":true,\"negotiated\":\"%s\",\"cipher\":\"%s\",\"session_reused\":false,\"response_bytes\":%zu}\n",elapsed,argv[2],SSL_get_cipher_name(ssl),want);
 SSL_free(ssl);SSL_CTX_free(ctx);close(fd);return 0;
}
