"""Optional new study. One invocation = one runtime session, never three independent sessions.
Observer off/on share the same communicate() completion mechanism. An external sampler
thread reads the client process at 1 ms intervals in the observer-on condition.
"""
from pathlib import Path
import os,subprocess,time,socket,threading,random,json,hashlib,platform,uuid,sys
import pandas as pd
import psutil

GROUPS=['X25519','X25519MLKEM768']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def compile_client(out, prefix=None):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    src=Path(__file__).with_name('tls_client.c');binary=out/'tls_client'
    flags=['-lssl','-lcrypto']
    if prefix:
        prefix=Path(prefix).resolve();lib=prefix/'lib'
        if not lib.exists():lib=prefix/'lib64'
        flags=['-I'+str(prefix/'include'),'-L'+str(lib),'-Wl,-rpath,'+str(lib),*flags]
    subprocess.run(['gcc','-O2','-Wall','-Wextra',str(src),'-o',str(binary),*flags],check=True,capture_output=True)
    return binary.resolve()

def collect(out,openssl='openssl',blocks=30,seed=20261105,prefix=None):
    out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
    binary=compile_client(out/'build',prefix)
    cert=out/'server.crt';key=out/'server.key';payload=out/'payload.bin'
    payload.write_bytes(b'TLS_BENCH_FIXED_RESPONSE\n'+b'A'*(256-len(b'TLS_BENCH_FIXED_RESPONSE\n')))
    subprocess.run([openssl,'req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(key),'-out',str(cert),'-days','2','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
    log=open(out/'server_private.log','wb')
    server=subprocess.Popen([openssl,'s_server','-accept',str(port),'-cert',str(cert),'-key',str(key),'-tls1_3','-groups',':'.join(GROUPS),'-WWW','-quiet'],cwd=out,stdout=log,stderr=log)
    for _ in range(200):
        if server.poll() is not None:raise RuntimeError('Server failed; inspect local private server log')
        try:
            socket.create_connection(('127.0.0.1',port),timeout=.1).close();break
        except OSError:time.sleep(.025)
    else:raise RuntimeError('Server readiness timeout')
    boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    identity=hashlib.sha256((boot+'|'+platform.node()).encode()).hexdigest()
    session_id=time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'-'+uuid.uuid4().hex[:8]
    rows=[]
    def run(group,observer,block,warmup=False):
        stop=threading.Event();rss=[];cpu=[]
        start=time.perf_counter_ns()
        proc=subprocess.Popen([str(binary),str(port),group,str(cert),str(payload)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        def sample():
            try:
                task=psutil.Process(proc.pid)
                while not stop.is_set():
                    try:
                        rss.append(task.memory_info().rss);t=task.cpu_times();cpu.append(t.user+t.system)
                    except (psutil.NoSuchProcess,psutil.AccessDenied):break
                    stop.wait(.001)
            except psutil.NoSuchProcess:pass
        thread=threading.Thread(target=sample,daemon=True) if observer else None
        if thread:thread.start()
        try:stdout,stderr=proc.communicate(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill();stdout,stderr=proc.communicate();raise RuntimeError('Client timeout')
        finally:stop.set()
        elapsed=(time.perf_counter_ns()-start)/1e6
        if thread:thread.join(timeout=2)
        if proc.returncode:raise RuntimeError('Client validation failed: '+stderr[:300])
        row=json.loads(stdout);row.update(session_id=session_id,runtime_fingerprint=identity,block=block,group=group,observer='on' if observer else 'off',process_ms=elapsed,sample_count=len(rss),sampled_peak_rss_mib=max(rss)/1048576 if rss else None,warmup=warmup)
        return row
    try:
        for g in GROUPS:
            for _ in range(5):run(g,False,-1,True)
        rng=random.Random(seed)
        for block in range(1,blocks+1):
            conditions=[(g,o) for g in GROUPS for o in [False,True]];rng.shuffle(conditions)
            for g,o in conditions:rows.append(run(g,o,block))
        # Disjoint-group control uses a separate validated client invocation.
        free=socket.socket();free.bind(('127.0.0.1',0));negative_port=free.getsockname()[1];free.close()
        disjoint=subprocess.Popen([openssl,'s_server','-accept',str(negative_port),'-cert',str(cert),'-key',str(key),'-tls1_3','-groups','X25519','-quiet'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        try:
            for _ in range(200):
                if disjoint.poll() is not None:raise RuntimeError('Negative-control server failed')
                try:
                    socket.create_connection(('127.0.0.1',negative_port),timeout=.1).close();break
                except OSError:time.sleep(.025)
            else:raise RuntimeError('Negative-control server readiness timeout')
            neg=subprocess.run([str(binary),str(negative_port),GROUPS[1],str(cert),str(payload)],capture_output=True,text=True,timeout=15)
            actual_alert='alert handshake failure' in neg.stderr.casefold()
            if disjoint.poll() is not None or neg.returncode==0 or not actual_alert:raise RuntimeError('Expected TLS handshake-failure alert was not observed')
            negative={'test':'disjoint requested groups','client_rejected':True,'server_started':True,'tls_handshake_failure_alert_observed':True}
        finally:disjoint.terminate();disjoint.wait(timeout=5)
    finally:
        server.terminate();server.wait(timeout=5);log.close()
        key.unlink(missing_ok=True);(out/'server_private.log').unlink(missing_ok=True)
    frame=pd.DataFrame(rows);frame.to_csv(out/'fresh_records.csv',index=False)
    cpu_model='unknown'
    for line in Path('/proc/cpuinfo').read_text().splitlines():
        if line.startswith('model name'):cpu_model=line.split(':',1)[1].strip();break
    exe=Path(subprocess.check_output(['which',openssl],text=True).strip()) if '/' not in openssl else Path(openssl)
    manifest=dict(session_id=session_id,runtime_fingerprint=identity,independent_sessions_observed=1,collection_design='randomized blocks of 2 groups x 2 observer states; both outcomes from each connection',blocks=blocks,warmups_per_group=5,seed=seed,platform=platform.platform(),cpu_model=cpu_model,cpu_count=os.cpu_count(),affinity=sorted(os.sched_getaffinity(0)),ram_bytes=psutil.virtual_memory().total,openssl_version=subprocess.check_output([openssl,'version','-a'],text=True),openssl_binary_sha256=sha(exe),client_binary_sha256=sha(binary),client_source_sha256=sha(Path(__file__).with_name('tls_client.c')),python=sys.version,linked_libraries=subprocess.check_output(['ldd',str(binary)],text=True),measurement='handshake_ms wraps SSL_connect; process_ms wraps client launch through communicate; TCP connect excluded only from handshake_ms',negative_control=negative,payload_bytes=256)
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2))
    summary=frame.groupby(['group','observer'])[['handshake_ms','process_ms']].median().reset_index();summary.to_csv(out/'fresh_medians.csv',index=False)
    return frame,manifest,summary

def require_independent_sessions(paths):
    manifests=[json.loads((Path(p)/'manifest.json').read_text()) for p in paths]
    ids=[x['runtime_fingerprint'] for x in manifests]
    if len(set(ids))<3:raise ValueError('Three distinct runtime fingerprints are required. Re-running a cell or starting three processes is not independent runtime replication.')
    return manifests

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--openssl',default='openssl');p.add_argument('--blocks',type=int,default=30);p.add_argument('--prefix');a=p.parse_args()
    _,_,s=collect(a.out,a.openssl,a.blocks,prefix=a.prefix);print(s.to_string(index=False))
