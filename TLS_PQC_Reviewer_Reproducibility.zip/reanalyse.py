"""Reproduce the archived single-session analysis. No TLS connections are made here."""
from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd

SEED = 20261105
B = 100000
GROUPS = ['X25519', 'X25519MLKEM768']

def analyse(raw, out):
    out = Path(out); out.mkdir(parents=True, exist_ok=True)
    required = ['iteration','pause_s','group','success','negotiated','verified','wall_ms','client_peak_rss_mb','client_cpu_sample_s','returncode']
    if set(required) - set(raw): raise ValueError('Missing required archive fields')
    if len(raw) != 60 or raw.duplicated(['iteration','pause_s','group']).any(): raise ValueError('Archive row count or duplicate key error')
    if raw[['wall_ms','client_peak_rss_mb','client_cpu_sample_s']].isna().any().any(): raise ValueError('Missing measurements')
    if not (raw.success.all() and raw.verified.all() and raw.returncode.eq(0).all()): raise ValueError('TLS validation failure in archive')
    if not all(str(row.negotiated).split(',')[0].strip().casefold()==str(row.group).casefold() for row in raw.itertuples()): raise ValueError('Negotiated group mismatch')
    cells=raw.groupby(['pause_s','group']).size()
    if len(cells)!=6 or not cells.eq(10).all() or set(raw.group)!=set(GROUPS) or set(raw.pause_s)!={0.0,0.01,0.05}: raise ValueError('Expected six archived cells of ten observations')
    rng = np.random.default_rng(SEED)
    summaries=[]; dispersion=[]; comparisons=[]; flagged=[]; sensitivities=[]
    for (pause,g),frame in raw.groupby(['pause_s','group'],sort=True):
        x=frame.wall_ms.to_numpy(dtype=float)
        q1,q3=np.quantile(x,[.25,.75],method='linear');iqr=q3-q1
        mask=(x<q1-1.5*iqr)|(x>q3+1.5*iqr)
        summaries.append(dict(pause_s=pause,group=g,n=len(x),mean_ms=x.mean(),median_ms=np.median(x),std_ms=x.std(ddof=1),p95_ms=np.quantile(x,.95,method='linear')))
        dispersion.append(dict(pause_s=pause,group=g,min_ms=x.min(),max_ms=x.max(),sd_ms=x.std(ddof=1),iqr_ms=iqr,mad_ms=np.median(abs(x-np.median(x))),iqr_flags=int(mask.sum())))
        for row in frame.loc[mask].itertuples():
            flagged.append(dict(record_id=getattr(row,'record_id',row.Index+1),iteration=row.iteration,pause_s=pause,group=g,wall_ms=row.wall_ms))
    for pause,frame in raw.groupby('pause_s',sort=True):
        c=frame.loc[frame.group.eq(GROUPS[0]),'wall_ms'].to_numpy(dtype=float)
        h=frame.loc[frame.group.eq(GROUPS[1]),'wall_ms'].to_numpy(dtype=float)
        # The groups are sampled independently. No iteration-index pairing occurs.
        cb=np.median(rng.choice(c,size=(B,len(c)),replace=True),axis=1)
        hb=np.median(rng.choice(h,size=(B,len(h)),replace=True),axis=1)
        delta=hb-cb;overhead=100*delta/cb
        lo,hi=np.quantile(delta,[.025,.975],method='linear')
        olo,ohi=np.quantile(overhead,[.025,.975],method='linear')
        mc,mh=np.median(c),np.median(h)
        comparisons.append(dict(pause_s=pause,classical_median_ms=mc,hybrid_median_ms=mh,delta_ms=mh-mc,delta_lo_ms=lo,delta_hi_ms=hi,overhead_pct=100*(mh-mc)/mc,overhead_lo_pct=olo,overhead_hi_pct=ohi,bootstrap_resamples=B,seed=SEED))
        cleaned=[]
        for x in [c,h]:
            q1,q3=np.quantile(x,[.25,.75],method='linear');iqr=q3-q1
            cleaned.append(x[(x>=q1-1.5*iqr)&(x<=q3+1.5*iqr)])
        sensitivities.append(dict(pause_s=pause,primary_delta_ms=mh-mc,flag_removed_delta_ms=np.median(cleaned[1])-np.median(cleaned[0]),classical_n_retained=len(cleaned[0]),hybrid_n_retained=len(cleaned[1]),primary_rows_deleted=0))
    frames=dict(summary=pd.DataFrame(summaries),comparison=pd.DataFrame(comparisons),dispersion=pd.DataFrame(dispersion),iqr_flags=pd.DataFrame(flagged),sensitivity=pd.DataFrame(sensitivities))
    for name,df in frames.items():df.to_csv(out/(name+'.csv'),index=False)
    settings=dict(seed=SEED,resamples=B,interval='pointwise 95% percentile',resampling='independent within each group and pause; n=10 per group',quantile_method='linear',rng='NumPy default_rng; one generator advanced across ascending pauses',estimand='median(hybrid) - median(classical)',overhead='100*(median(hybrid)-median(classical))/median(classical)',multiplicity='no simultaneous or familywise adjustment',independence='working within-session assumption; runtime dependence and observer bias are not corrected',outliers='all rows retained in primary analysis; IQR flags are exploratory diagnostics only')
    (out/'analysis_settings.json').write_text(json.dumps(settings,indent=2))
    return frames

def figures(raw, frames, out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    out=Path(out);colors=['#0072B2','#D55E00']
    fig,ax=plt.subplots(figsize=(5.7,3.5))
    for gi,g in enumerate(GROUPS):
        for pi,pause in enumerate(sorted(raw.pause_s.unique())):
            x=raw.loc[raw.group.eq(g)&raw.pause_s.eq(pause),'wall_ms'].to_numpy()
            xpos=pi+(gi-.5)*.23
            ax.scatter(xpos+np.linspace(-.035,.035,len(x)),x,color=colors[gi],s=20,alpha=.8,label=g if pi==0 else None)
            ax.plot([xpos-.09,xpos+.09],[np.median(x)]*2,c='black',lw=1.5)
    ax.set_xticks(range(3),['0','0.01','0.05']);ax.set_xlabel('Pre-run scheduling pause (s)');ax.set_ylabel('Client process elapsed time (ms)');ax.grid(axis='y',alpha=.2);ax.legend(frameon=False,fontsize=8);fig.tight_layout();fig.savefig(out/'elapsed_points.png',dpi=300);plt.close(fig)
    mat=frames['comparison'];fig,ax=plt.subplots(figsize=(5.7,2.9))
    y=np.arange(len(mat));v=mat.overhead_pct.to_numpy();lo=mat.overhead_lo_pct.to_numpy();hi=mat.overhead_hi_pct.to_numpy()
    ax.errorbar(v,y,xerr=np.vstack([v-lo,hi-v]),fmt='o',capsize=4,color=colors[0],lw=1.4)
    ax.axvline(0,c='black',ls='--',lw=.9);ax.set_yticks(y,[f'{x:g}' for x in mat.pause_s]);ax.invert_yaxis();ax.set_xlabel('Hybrid median process overhead (%)');ax.set_ylabel('Pre-run pause (s)');ax.grid(axis='x',alpha=.2);fig.tight_layout();fig.savefig(out/'overhead_intervals.png',dpi=300);plt.close(fig)

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--data',default='data/benchmark_raw_sanitized.csv');p.add_argument('--out',default='results');a=p.parse_args()
    raw=pd.read_csv(a.data);frames=analyse(raw,a.out);figures(raw,frames,a.out)
    print(frames['comparison'].to_string(index=False))
