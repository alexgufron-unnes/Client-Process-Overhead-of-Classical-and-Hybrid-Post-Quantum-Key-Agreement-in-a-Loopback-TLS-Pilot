# TLS PQC reviewer revision reproducibility package

This package supports a single-session preliminary secondary analysis of 60 genuine archived observations. It does not contain three newly collected scientific sessions.

## Reproduce the paper

Install requirements.txt, then run:
    python reanalyse.py --data data/benchmark_raw_sanitized.csv --out regenerated

The notebook embeds the same sanitized records and executable scripts. Run all default cells to reproduce summaries, independent two-sample bootstrap intervals, dispersion flags, sensitivity calculations, and figures. Seed20261105;100000 resamples;pointwise95%percentile intervals. Keep every observation in the primary analysis.

data/bootstrap_ci.csv is the legacy arbitrary-index-paired result and is not the new principal interval. The new intervals target the difference of group medians.

## Collect the planned new study

Set RUN_NEW_SESSION=True in the notebook on each of at least three independently provisioned Colab runtimes. Each invocation produces one session with30randomized blocks of two groups by two observer states. An internal SSL_connect timer and a complete process timer provide different outcomes. Record CPU/model, library linkage, binary hashes, fixed payload and negative control. The function require_independent_sessions rejects repeated runtime fingerprints. A local two-block smoke test only validates software behavior; its measurements are excluded from this package's scientific results.

## Sanitization

Every one of the60 numerical records is retained. Diagnostic text is dropped by allowlist. No TLS session ticket, session identifier, resumption secret, private key, or private server log is included. The source ZIP is not redistributed because it contains unsanitized diagnostics. Source provenance and checksums accompany the sanitized data.

## Publication status

The package is prepared as a submission supplement. It has not been deposited in a public repository and has no persistent identifier. An author-controlled repository, release registration and final licensing decision remain necessary. No invented DOI or repository URL is used.
