"""Optional Colab build of OpenSSL 3.5.4; verifies publisher SHA-256 before extraction."""
from pathlib import Path
import subprocess,urllib.request,hashlib,re,tarfile,os,inspect

def ensure_openssl(root, executable='openssl'):
    probe=subprocess.run([executable,'list','-tls-groups'],capture_output=True,text=True)
    if probe.returncode==0 and 'X25519MLKEM768' in probe.stdout:return executable,None
    root=Path(root).resolve();root.mkdir(parents=True,exist_ok=True)
    url='https://www.openssl.org/source/openssl-3.5.4.tar.gz'
    archive=root/'openssl-3.5.4.tar.gz'
    with urllib.request.urlopen(url,timeout=60) as r:archive.write_bytes(r.read())
    with urllib.request.urlopen(url+'.sha256',timeout=60) as r:checksum_text=r.read().decode()
    match=re.search(r'\b[0-9a-fA-F]{64}\b',checksum_text)
    if not match:raise RuntimeError('Publisher checksum unavailable; do not build unverified bytes')
    digest=hashlib.sha256(archive.read_bytes()).hexdigest()
    if digest!=match.group().lower():raise RuntimeError('OpenSSL source checksum mismatch')
    with tarfile.open(archive) as tf:
        if 'filter' in inspect.signature(tf.extractall).parameters:
            tf.extractall(root,filter='data')
        else:
            # Compatible with Python 3.10: reject links, special files and traversal.
            for member in tf.getmembers():
                target=(root/member.name).resolve()
                if not target.is_relative_to(root) or not (member.isfile() or member.isdir()):
                    raise RuntimeError('Unsafe archive member; use an updated Python runtime')
            tf.extractall(root)
    source=root/'openssl-3.5.4';prefix=root/'install'
    subprocess.run(['./Configure','--prefix='+str(prefix),'--libdir=lib','shared'],cwd=source,check=True)
    subprocess.run(['make','-j',str(min(2,os.cpu_count() or 1))],cwd=source,check=True)
    subprocess.run(['make','install_sw'],cwd=source,check=True)
    os.environ['LD_LIBRARY_PATH']=str(prefix/'lib')+(':'+os.environ['LD_LIBRARY_PATH'] if os.environ.get('LD_LIBRARY_PATH') else '')
    binary=str(prefix/'bin/openssl')
    probe=subprocess.run([binary,'list','-tls-groups'],capture_output=True,text=True,check=True)
    if 'X25519MLKEM768' not in probe.stdout:raise RuntimeError('Built OpenSSL lacks requested group')
    (root/'source_sha256.txt').write_text(digest+'  openssl-3.5.4.tar.gz\n')
    return binary,str(prefix)
