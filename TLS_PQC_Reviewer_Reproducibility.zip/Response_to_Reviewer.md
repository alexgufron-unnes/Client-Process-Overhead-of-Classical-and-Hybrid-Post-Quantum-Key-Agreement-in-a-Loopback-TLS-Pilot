# Response to reviewer

We thank the reviewer for identifying the estimand mismatch and measurement limitations. This revision strengthens the secondary analysis while distinguishing completed revisions from empirical and repository work that remains pending.

The revised manuscript is titled “Single Session Preliminary Observations of Classical and Hybrid Post Quantum TLS Client Process Timing”.

Completed changes do not establish that observer bias has been removed or that three independent scientific sessions have been run. The local collector smoke test checks software operation only.

## Major 1 Research gap and novelty

Status: Revised

Location: Introduction and Literature review

The final Introduction paragraph now states the archive-specific evidence gap, the mismatch between the prior interval and the headline statistic, the reanalysis contribution, and three objectives. The Literature review connects prior TLS, implementation and statistical work to those objectives. We do not claim a new protocol or an undocumented absence of earlier hybrid TLS studies.

## Major 2 Observer perturbation and internal timing

Status: Partially addressed; new empirical control pending

Location: Method 3.2; notebook 5; collect_controls.py and tls_client.c

We state that observer perturbation cannot be estimated from the archived data. The new optional collector randomizes observer off/on and both groups within blocks, uses the same completion mechanism, and measures SSL_connect internally with CLOCK_MONOTONIC. A local two-block smoke test passes compilation, certificate/group/full-session/fixed-payload checks and incompatible-group rejection. Those validation observations are not substituted for the archive. Scientifically adequate observer controls in the target independent sessions remain to be collected.

## Major 3 Estimand-matched statistics and pauses

Status: Revised with conditional-inference limits

Location: Method 3.3–3.4; Results 4.2; Table 3; Figure 3

The main analysis replaces arbitrary index pairing with 100,000 independent within-group resamples, seed 20261105. Pointwise 95% intervals for the difference of medians are [0.077, 1.653], [−0.224, 1.160] and [−0.191, 1.053] ms. The abstract gives those intervals. Percent overhead is recalculated within every resample. We explicitly acknowledge the working exchangeability assumption, small n, one-session dependence and absence of multiplicity adjustment. The inherited pause is a descriptive pacing stratum; we make no causal pause-response interpretation.

## Major 4 Narrow dispersion and extreme values

Status: Revised; physical cause unidentifiable

Location: Method 3.4; Results 4.3; Table 4; notebook 3

We inspect and retain all 60 raw values. The hybrid 0.01 s cell contains ten distinct values across noncontiguous run positions, range 11.898342–12.141034 ms, SD 0.067658 ms and MAD 0.022009 ms. The archive lacks evidence for a physical explanation, which we state. An exploratory IQR rule flags four hybrid observations; none is excluded from primary summaries or intervals. Flag-removal sensitivity changes point differences to 0.884, 0.742, 0.376 ms and is explicitly secondary.

## Major 5 Single session and documentation

Status: Reframed; independent replication pending

Location: Title; Abstract; Method 3.1–3.2; Results 4.6; notebook 5–6

The title and abstract now identify single-session preliminary observations. We do not infer independent sessions from repeated process launches. The new collector records CPU, affinity, RAM, source/binary hashes and linked libraries, and the notebook requires three distinct runtime fingerprints before a three-session summary. At least three independently provisioned target-runtime sessions remain necessary. The original CPU model and binary hash cannot be retrospectively recovered.

## Major 6 Public data and persistent identifier

Status: Sanitization completed; public deposit pending

Location: Data Availability; Supplement S 1

We have acted on sanitization: diagnostic text is removed with an allowlist, every numerical row is retained, and the package contains analysis source, notebook, results, provenance and checksums. The internal editorial note was removed from the manuscript. No public repository or persistent identifier has been created. The revised statement describes the actual submission supplement without claiming a deposit. The authors must select an authorized public repository and register a persistent release identifier before this request can be marked complete.

## Major 7 At least 25 references and relevant methods literature

Status: Revised

Location: Literature review; Methods; References; RIS

The bibliography now contains 27 published references, including 24 journal articles (88.9%). Additions cover post-quantum TLS surveys, PKI/signature costs, ML-KEM primitives, executable/in-process benchmarking, effect estimation, bootstrap intervals and reproducibility. All additions are published journal records within the preceding ten years. Journal abbreviations, available months, DOI metadata and Art. no. usage were standardized.

## Major 8 Scope and residual text

Status: Revised

Location: Entire manuscript

The unsupported RFID motivation and unrelated intrusion-detection and food-loss residues are removed. The scope now concerns the archived TLS process measurement. Device and energy studies remain only as cited context explaining measurement boundaries.

## Minor Quantitative comparison and repetitive discussion

Status: Revised

Location: Results 4.5; Table 7

The revised comparison gives published HTTP first-byte overheads and their uncertainty, and MQTT/TLS handshake-completion values, alongside software/authentication/boundary information. We do not pool unlike metrics. The discussion is shortened and interprets differences rather than repeating the literature survey.

## Minor Figures and bootstrap table

Status: Revised

Location: Figures 1–3; Table 3; notebook 4

The workflow is redrawn at readable print size. The shaded percentage panel is replaced with an explicit-axis interval plot. The former legacy interval table is replaced by the estimand-matched Table 3; the old CSV remains labelled legacy in the supplement for traceability. Displayed negative bounds use a true minus sign. Settings and pointwise-interval qualifications accompany the table and figure.

## Minor Conclusion

Status: Revised

Location: Conclusion

One main paragraph answers the research objectives and states what uncertainty permits. A short subsequent paragraph identifies limitations and the required independent-session follow-up.

## Minor Abstract and keywords

Status: Revised

Location: Front matter

The 153-word IMRAD abstract is standalone, names the single-session scope, reports uncertainty and contains no reference to other evaluations. Keywords consistently use post-quantum.

## Minor CRediT and AI disclosure

Status: Revised

Location: Declarations

The name-colon-role format follows the template and preserves author-confirmed roles. CRediT role names use standard wording. The AI disclosure names affected manuscript sections, captions, reviewer response, analysis, plotting and optional collector/notebook code, while stating that archived measurements were not generated or altered by AI.

## Minor IEEE references

Status: Revised

Location: References; RIS

References use first-citation numbering, abbreviated journal titles, available publication months, consistent article-number labels and live DOI links. Word citations target reference bookmarks; Markdown uses matching anchors.

## Annotated manuscript anchors

Status: Not independently checked

Location: Review material

The detailed annotated manuscript was not attached to this revision request. This response addresses every major and minor item in the pasted review. Additional file-specific anchors require the annotated file before they can be verified.

## Items required before resubmission

1. Collect the planned observer off/on and internal-handshake conditions in at least three independently provisioned target runtimes.
2. Inspect new session records and perform prespecified block/session-aware inference.
3. Deposit the sanitized package in an author-controlled repository and obtain a persistent release identifier.
4. Update the data statement with the verified repository/PID and check any additional anchored comments in the annotated manuscript.
